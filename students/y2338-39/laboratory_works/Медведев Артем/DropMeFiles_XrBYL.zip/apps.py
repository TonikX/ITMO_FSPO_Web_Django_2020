from django.apps import AppConfig


class FinalAppConfig(AppConfig):
    name = 'final_app'
